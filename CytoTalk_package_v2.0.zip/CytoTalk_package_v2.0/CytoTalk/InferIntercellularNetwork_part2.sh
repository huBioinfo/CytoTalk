#!/bin/bash

#$ -o Step1.log

#$ -cwd



#Infer the signaling network between two specified cell types.
#Input: "scRNAseq_Fibroblasts/Macrophages/EndothelialCells/.../xxx.csv", "TwoCellTypes.txt", "Species.txt", "BetaUpperLimit.txt" and "Cutoff_GeneFilter.txt".
#Output: An output folder, /Cytotalk/IllustratePCSF/, contains a network file "PCSF_edgeSym.sif" and six attribute files that are ready for import into Cytoscape.


#4) Construct the integrated gene network.
date +%D-%H:%M:%S
echo "(4/6) Constructing the integrated gene network...(around 5 min)"
Rscript comp_NonSelfTalkScore_TypA.R
Rscript comp_NonSelfTalkScore_TypB.R
matlab -nodisplay -nodesktop -nosplash -r construct_integratedNetwork  #one should specify the absolute path of the executable Matlab program.

#5) Generate multiple PCSFs based on the integrated gene network.
date +%D-%H:%M:%S
echo "(5/6) Generating multiple PCSFs...(around 20 min)"
bash JobRun_Parallel.sh

#6) Generate the final signaling network between the two cell types.
date +%D-%H:%M:%S
echo "(6/6) Generating the final signaling network between the two cell types...(around 60 min)"
matlab -nodisplay -nodesktop -nosplash -r gen_signalingNetwork  #one should specify the absolute path of the executable Matlab program.
echo "ALL DONE! CytoTalk has generated output files in the folder: /CytoTalk/IllustratePCSF/"
date +%D-%H:%M:%S


