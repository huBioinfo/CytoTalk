function [] = gen_CytoFileFun(beta_final,omega_final)
%GEN_CYTOFILEFUN Summary of this function goes here
%   Detailed explanation goes here

ResultFileName=strcat('./bt',num2str(beta_final,'%.6f'),'/bt',num2str(beta_final,'%.6f'),'_omg',num2str(omega_final),'/pcsf_result4');
load(ResultFileName);

load Exp_cleaned_2 TypAExp_rmRep_dmNew
load Exp_cleaned_4 TypBExp_rmRep_dmNew
load IntegratedNet_TypATypB_ID
load Crosstalk_TypATypB crosstalk_Sym crosstalk_Sco

%---------Extract gene expression of resulting PCSF.
PCSF_geneExp=zeros(length(PCSF_nodeSym),1);
PCSF_geneCellType=zeros(length(PCSF_nodeSym),1); %-"1" as TypA; "2" as TypB.
for i=1:length(PCSF_nodeSym)
    %---------progress bar-------------%
%     fprintf('PCSF_nodeSym %d.\n',i);
    %----------------------------------%
    if strcmp(PCSF_nodeSym{i}(end-5:end),'__TypA') %-if true, it's TypA.
        PCSF_geneCellType(i)=1; %-"1" as TypA.
        vec=strcmp(PCSF_nodeSym{i}(1:end-6),TypAExp_rmRep_dmNew.RowNames); 
        ind=find(vec); %-must have a single value.
        PCSF_geneExp(i)=mean(double(TypAExp_rmRep_dmNew(ind,:)));
    elseif strcmp(PCSF_nodeSym{i}(end-5:end),'__TypB') %-if true, it's TypB.
        PCSF_geneCellType(i)=2; %-"2" as TypB.
        vec=strcmp(PCSF_nodeSym{i}(1:end-6),TypBExp_rmRep_dmNew.RowNames); 
        ind=find(vec); %-must have a single value.
        PCSF_geneExp(i)=mean(double(TypBExp_rmRep_dmNew(ind,:)));
    end
end

%---------Extract gene prize of resulting PCSF.
PCSF_genePrize=zeros(length(PCSF_nodeSym),1);
for i=1:length(PCSF_nodeSym)
    %---------progress bar-------------%
%     fprintf('PCSF_nodeSym %d.\n',i); 
    %----------------------------------%
    vec=strcmp(PCSF_nodeSym(i),integratedNet_GeneSym);
    ind=find(vec);
    PCSF_genePrize(i)=integratedNet_GenePrize_initial(ind);
end

%---------Extract gene Real Name of resulting PCSF.
PCSF_geneRealName=cell(length(PCSF_nodeSym),1);
for i=1:length(PCSF_nodeSym)
    %---------progress bar-------------%
%     fprintf('PCSF_nodeSym %d.\n',i); 
    %----------------------------------%
    PCSF_geneRealName{i}=PCSF_nodeSym{i}(1:end-6);
end
save pcsf_resultCyto PCSF_nodeSym PCSF_geneExp PCSF_geneCellType PCSF_edgeSym PCSF_edgeIndex PCSF_edgeCost PCSF_edgeCellType isolatedNode PCSF_genePrize PCSF_geneRealName


%-------------------Generate files for Cytoscape--------------------------%
%-format the gene symbol to replace "TypA" and "TypB" by real cell type
%names.
load CellTypeName
for p=1:size(PCSF_edgeSym,1)
    for q=1:size(PCSF_edgeSym,2)
        
        if strcmp(PCSF_edgeSym{p,q}(end-3:end),'TypA')
            PCSF_edgeSym{p,q}=strcat(PCSF_edgeSym{p,q}(1:end-4),CellTypeA);
        elseif strcmp(PCSF_edgeSym{p,q}(end-3:end),'TypB')
            PCSF_edgeSym{p,q}=strcat(PCSF_edgeSym{p,q}(1:end-4),CellTypeB);
        end
        
    end
end

for kk=1:length(PCSF_nodeSym)
    if strcmp(PCSF_nodeSym{kk}(end-3:end),'TypA')
        PCSF_nodeSym{kk}=strcat(PCSF_nodeSym{kk}(1:end-4),CellTypeA);
    elseif strcmp(PCSF_nodeSym{kk}(end-3:end),'TypB')
        PCSF_nodeSym{kk}=strcat(PCSF_nodeSym{kk}(1:end-4),CellTypeB);
    end
end


%-create a folder for Cytoscape files.
status_1=mkdir('./IllustratePCSF/');

fid1=fopen('./IllustratePCSF/PCSF_edgeSym.sif','w');
formatSpec_1='%s\t%s\t%s\n';
for i=1:size(PCSF_edgeSym,1)
    
    fprintf(fid1,formatSpec_1,PCSF_edgeSym{i,1},'pp',PCSF_edgeSym{i,2});
    
end
fclose(fid1);

fid2=fopen('./IllustratePCSF/PCSF_edgeCost.txt','w');
formatSpec_2='%s %s %s\t%f\n';
fprintf(fid2,'%s\t%s\n','EdgeSym','EdgeCost');
for i=1:size(PCSF_edgeSym,1)

    fprintf(fid2,formatSpec_2,PCSF_edgeSym{i,1},'(pp)',PCSF_edgeSym{i,2},PCSF_edgeCost(i));
    
end
fclose(fid2);

fid5=fopen('./IllustratePCSF/PCSF_edgeCellType.txt','w');
formatSpec_5='%s %s %s\t%d\n';
fprintf(fid5,'%s\t%s\n','EdgeSym','EdgeCellType');
for i=1:size(PCSF_edgeSym,1)

    fprintf(fid5,formatSpec_5,PCSF_edgeSym{i,1},'(pp)',PCSF_edgeSym{i,2},PCSF_edgeCellType(i));
    
end
fclose(fid5);

fid3=fopen('./IllustratePCSF/PCSF_geneExp.txt','w');
formatSpec_3='%s\t%f\n';
fprintf(fid3,'%s\t%s\n','GeneSym','GeneExp');
for i=1:length(PCSF_nodeSym)

    fprintf(fid3,formatSpec_3,PCSF_nodeSym{i},PCSF_geneExp(i));
    
end
fclose(fid3);

fid4=fopen('./IllustratePCSF/PCSF_geneCellType.txt','w');
formatSpec_4='%s\t%d\n';
fprintf(fid4,'%s\t%s\n','GeneSym','GeneCellType');
for i=1:length(PCSF_nodeSym)

    fprintf(fid4,formatSpec_4,PCSF_nodeSym{i},PCSF_geneCellType(i));
    
end
fclose(fid4);

fid6=fopen('./IllustratePCSF/PCSF_genePrize.txt','w');
formatSpec_6='%s\t%f\n';
fprintf(fid6,'%s\t%s\n','GeneSym','GenePrize');
for i=1:length(PCSF_nodeSym)

    fprintf(fid6,formatSpec_6,PCSF_nodeSym{i},PCSF_genePrize(i));
    
end
fclose(fid6);

fid7=fopen('./IllustratePCSF/PCSF_geneRealName.txt','w');
formatSpec_7='%s\t%s\n';
fprintf(fid7,'%s\t%s\n','GeneSym','GeneRealName');
for i=1:length(PCSF_nodeSym)
    
    fprintf(fid7,formatSpec_7,PCSF_nodeSym{i},PCSF_geneRealName{i});
    
end
fclose(fid7);


%-----------Generate a txt file for identified crosstalk edges along with their original crosstalk scores--------%
%-extract original crosstalk scores for identified crosstalk edges.
crosstalk_edgeSco_orig=zeros(size(crosstalk_edgeSym,1),1);
for i=1:size(crosstalk_edgeSym,1)
    ind_11=find(strcmp(crosstalk_edgeSym{i,1},crosstalk_Sym(:,1)));
    ind_22=find(strcmp(crosstalk_edgeSym{i,2},crosstalk_Sym(:,2)));
    ind_final=intersect(ind_11,ind_22); %must have a single value.
    crosstalk_edgeSco_orig(i)=crosstalk_Sco(ind_final);
end

%-format the crosstalk edge symbol to replace "TypA" and "TypB" by real cell type
%names.
load CellTypeName
for p=1:size(crosstalk_edgeSym,1)
    for q=1:size(crosstalk_edgeSym,2)
        
        if strcmp(crosstalk_edgeSym{p,q}(end-3:end),'TypA')
            crosstalk_edgeSym{p,q}=strcat(crosstalk_edgeSym{p,q}(1:end-6),' (',CellTypeA,')');
        elseif strcmp(crosstalk_edgeSym{p,q}(end-3:end),'TypB')
            crosstalk_edgeSym{p,q}=strcat(crosstalk_edgeSym{p,q}(1:end-6),' (',CellTypeB,')');
        end
        
    end
end

%-sort the formatted crosstalk edges based on original crostalk score.
[crosstalk_edgeScoSorted_orig,indind]=sort(crosstalk_edgeSco_orig,'descend');
crosstalk_edgeSymSorted=crosstalk_edgeSym(indind,:);

fid8=fopen('./IllustratePCSF/PCSF_CrosstalkEdge.txt','w');
formatSpec_8='%s\t%s\t%f\n';
fprintf(fid8,'%s\t%s\t%s\n','Ligand','Receptor','CrosstalkScore');
for i=1:size(crosstalk_edgeSymSorted,1)

    fprintf(fid8,formatSpec_8,crosstalk_edgeSymSorted{i,1},crosstalk_edgeSymSorted{i,2},crosstalk_edgeScoSorted_orig(i));
    
end
fclose(fid8);
        

end


